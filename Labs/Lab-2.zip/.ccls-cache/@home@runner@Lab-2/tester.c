#include <stdio.h>
#include <stdlib.h>

/* adding a comment */
void * dynamic_array_append(int ** array, int * size) 
{
    int i;
    int n1, n2;
    int new_size = *size + 1;
    int ** new_addr = (int **) realloc(array, new_size * (int)sizeof(int));

    if (new_addr == NULL) {
        printf("ERROR: unable to realloc memory \n");
        return NULL;
    }

/*
    if (*size == 0 || *size == 1) {
        new_addr[*size] = *size;
    }

  
    n1 = new_addr[size-1];
    n2 = new_addr[size];
*/
  if(new_size-1 == 0){
    new_addr[new_size-1] = 0;
  }else if (new_size-1 == 1){
    new_addr[new_size-1] = 1;
  } else{
        new_addr[new_size-1] = new_addr[new_size-2] + 1;
  }
}


/*
int main() {

    int i, length, original, *n, size=0, *array = NULL;
    length = 5;
    original = length;
    n = &length;  

    array = (int*)malloc(sizeof(int)*5);
    append(&array, n, 5);
    


    for (i=0 ; i<original+1 ; i++)
      printf("array[%d] = %d\n", i, array[i]);

    return 0;
}*/

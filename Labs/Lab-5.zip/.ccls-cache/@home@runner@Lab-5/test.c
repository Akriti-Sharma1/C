#include "extras.c"
#include "lab5.c"
void disrupt(Graph *gr, char *station){
  Enode* temp = (Enode*) malloc(sizeof(Enode));
  for(int i = 0; i < gr->count; i++){
    if((gr->adj_list[i]->station == station)){
      temp = &gr->adj_list[i]->edges[i];
      gr->adj_list[i]->edges[i].next = gr->adj_list[i]->edges[i+1].next;
    }
  }
  free(temp);
}



int main(){
  Graph *gr = initialize_graph();
  add(gr, "Kipling");
  add(gr, "Spadina");
  add(gr, "Yorkdale");

  update(gr, "Kipling", "Spadina", 12);
  update(gr, "Spadina", "Yorkdale", 8);
  update(gr, "Spadina", "Bay", 2);
  update(gr, "Spadina", "Union", 4);
  update(gr, "Bay", "Bloor-Yonge", 1);
  update(gr, "Union", "Bloor-Yonge", 3);
  update(gr, "Bloor-Yonge", "Kennedy", 14);
  update(gr, "Bloor-Yonge", "Sheppard-Yonge", 11);
  update(gr, "Sheppard-Yonge", "Finch", 3);
  update(gr, "Sheppard-Yonge", "Don Mills", 6);
  disrupt(gr, "Bay");
}
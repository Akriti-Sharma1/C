#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct party_node{

  char* item; // name of the party item
  double price; // price of the item
  char* ta; // name of TA requesting the item
  struct party_node *next; // pointer to the next node
} typedef party_node;

void sortedInsert(struct party_node** head, struct party_node* newNode)
{
    struct party_node dummy;
    struct party_node* current = &dummy;
    dummy.next = *head;
 
    while (current->next != NULL && current->next->price < newNode->price) {
        current = current->next;
    }
 
    newNode->next = current->next;
    current->next = newNode;
    *head = dummy.next;
}
 
// Given a list, change it to be in sorted order (using `sortedInsert()`).
void make_sorted(struct party_node** head)
{
    struct party_node* result = NULL;     // build the answer here
    struct party_node* current = *head;   // iterate over the original list
    struct party_node* next;
 
    while (current != NULL)
    {
        // tricky: note the next pointer before we change it
        next = current->next;
 
        sortedInsert(&result, current);
        current = next;
    }
 
    *head = result;
    reverse(head);
}

void reverse(struct party_node** head_ref)
{
    struct party_node* prev = NULL;
    struct party_node* current = *head_ref;
    struct party_node* next = NULL;
    while (current != NULL) {
        // Store next
        next = current->next;
  
        // Reverse current node's pointer
        current->next = prev;
  
        // Move pointers one position ahead.
        prev = current;
        current = next;
    }
    *head_ref = prev;
}

int add_request(struct party_node **head , char *item , double price , char *ta){
  if (strcmp(item, "IDE") != 0){
    struct party_node* new_node = (struct party_node*)malloc(sizeof(struct party_node));

    new_node->item = malloc(strlen(item)+1);
    new_node->ta = malloc(strlen(ta)+1);

    strcpy(new_node->item, item);
    strcpy(new_node->ta, ta);
    /*allocated dynamically*/
    new_node->price = price;
    new_node->next = (*head);

    (*head) = new_node;
    return 0;
  } return -1;
}

void remove_request(struct party_node **head){
  if ((*head) == NULL){
    return;
  }
  
  struct party_node* temp = (*head);
  (*head) = (*head)->next;

  free(temp->item);
  free(temp->ta);
  free(temp);
  
  
}

void print_list(struct party_node *head){
    int count = 1;
    printf("The current list contains:\n");
    while(head!=NULL){
        printf("Item %d: %s, %.2lf, requested by %s\n",
            count, head->item, head->price, head->ta);
        count++;
        head = head->next;
    }
    printf("\n\n");
    return;
}

double finalize_list(struct party_node **head , double budget ){
  double counter = 0.00;
  while((*head)->price > budget){
    remove_request(head);

  }
  
  struct party_node *temp = (*head)->next;
  struct party_node *prev= (*head);

  counter = counter + (*head)->price;
while(temp!=NULL)
{
  /*printf("I'm checking %f\n", (temp->price)+counter);*/
  
  if ((temp->price) > (budget-counter)){
    /*printf("I'm deleting %f", (temp->price)+counter);*/
    prev->next = temp->next;
    struct party_node *helper = temp;
    free(helper->ta);
    free(helper->item);
    free(helper);
    temp = temp->next;
    
  } else{
    /*printf("I'm here\n");*/
    counter = counter + (temp->price);
    prev = temp;
    temp = temp->next;
  }
  return budget-counter;
     
}}
/*
void freeList(struct party_node* head)
{
   struct node* tmp;

   while (head != NULL)
    {
       tmp = *head;
       head = head->next;
       free(tmp);
    }

}*/

/*
int main(){
  struct party_node* head = NULL;
  struct party_node* second = NULL;
  struct party_node* third = NULL;

  head = (struct party_node*)malloc(sizeof(struct party_node));
  second = (struct party_node*)malloc(sizeof(struct party_node));
  third = (struct party_node*)malloc(sizeof(struct party_node));
/*
  char item1[250] = "Chips";
  char ta1[250] = "Sam";

  head->item = item1;
  head->ta = ta1;
  head->price = 5.50;
  head->next = NULL;*/
/*
  char item2[250] = "Cake";
  char ta2[250] = "Beth";
  
  char item3 = "Cookies";
  char ta3 = "Chris";
  add_request(&head, "Pop", 150.00, "Beth");
  add_request(&head, "Chips", 5.50, "Chris");
  add_request(&head, "Cake", 8.00, "Beth");
  add_request(&head, "Cookies", 1.00, "Chris");
  

  printf("Here is my list before deleting:\n");
  make_sorted(&head);
  print_list(head);
  printf("\n");
  
  printf("Here is my list after deleting:\n");
  /*remove_request(&head);
  
  finalize_list(&head, 8.00);
  print_list(head);
}*/
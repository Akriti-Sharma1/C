#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct party_node{

  char* item; // name of the party item
  double price; // price of the item
  char* ta; // name of TA requesting the item
  struct party_node *next; // pointer to the next node
} typedef party_node;

int add_request(struct party_node **head , char *item , double price , char *ta){
  if (strcmp(item, "IDE") != 0){
    struct party_node* new_node = (struct party_node*)malloc(sizeof(struct party_node));

    new_node->item = item;
    new_node->ta = ta;
    new_node->price = price;
    new_node->next = (*head);

    (*head) = new_node;
    return 0;
  } return -1;
}

void remove_request(struct party_node *head){
  if (head == NULL){
    return NULL;
  }
  
  struct party_node* temp = head;
  head = head->next;

  free(temp);
  
  /*return head;*/
}

void make_sorted(struct party_node** head)
{
    struct party_node* result = NULL;     // build the answer here
    struct party_node* current = *head;   // iterate over the original list
    struct party_node* next;
 
    while (current != NULL)
    {
        // tricky: note the next pointer before we change it
        next = current->next;
 
        sortedInsert(&result, current);
        current = next;
    }
 
    *head = result;
    reverse(head);
}

void reverse(struct party_node** head_ref)
{
    struct party_node* prev = NULL;
    struct party_node* current = *head_ref;
    struct party_node* next = NULL;
    while (current != NULL) {
        // Store next
        next = current->next;
  
        // Reverse current node's pointer
        current->next = prev;
  
        // Move pointers one position ahead.
        prev = current;
        current = next;
    }
    *head_ref = prev;
}

int main(){
  struct party_node* head = NULL;
  struct party_node* second = NULL;
  struct party_node* third = NULL;

  head = (struct party_node*)malloc(sizeof(struct party_node));
  second = (struct party_node*)malloc(sizeof(struct party_node));
  third = (struct party_node*)malloc(sizeof(struct party_node));

  char item1[250] = "Chips";
  char ta1[250] = "Sam";

  head->item = &item1;
  head->ta = &ta1;
  head->price = 5.50;
  head->next = NULL;

  char item2[250] = "Cake";
  char ta2[250] = "Beth";
  
  char item3[250] = "IDE";
  char ta3[250] = "Chris";

  add_request(&head, &item3, 1.00, &ta3);
  add_request(&head, &item2, 5.50, &ta2);
  printf("Here is my list before sorting:\n");
  printList(head);
  printf("\n\n");
  
  printf("Here is my list after sorting:\n");
  /*head = remove_request(head);*/
  make_sorted(&head);
  printList(head);
}
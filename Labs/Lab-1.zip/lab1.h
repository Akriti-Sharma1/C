double split_bill(double base_amount , double tax_rate, double tip_rate , int num_people );

double adjust_price(double original_price);

int sandy_eats(char menu_item []);

void imagine_fish(char thing []);
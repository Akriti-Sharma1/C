#include<stdio.h>
#include<math.h>
#include<string.h>



int sandy_eats(char menu_item[]){
 
char* p = menu_item;
while(*p!='\0'){ 
  if(*p =='J' || *p =='K'|| *p =='L')
   return 0;
  if(*p >= '0' && *p<='9'  && (*p) %2 != 0)
   return 0;
  p++;
 }

const char needle[4] = "fish";
    char *ret;
    ret = strstr(menu_item, needle);
    if(ret == NULL)
     return 1;
     else
     return 0;
}



int main(){   

 char test_food1[] = "jelly fish";
    int test_p31 = sandy_eats(test_food1);
    if (test_p31 == 0){
        printf("Sandy would NOT eat '%s'.\n", test_food1);
    }
    else {
        printf("Sally would eat '%s'.\n", test_food1);
    
    }

}

#include "a1.h"

Menu* load_menu(char* fname) {
  // CREATE A STRUCT 
    Menu* menu = (struct Menu*) malloc(sizeof(struct Menu));
    // +21 is for cost (we don't know the max). +3 is for 2 commas and \n at the end
    char line[21+ITEM_CODE_LENGTH+MAX_ITEM_NAME_LENGTH+3];
    FILE* file;
    int num_items = 0;
    file = fopen(fname, "r");
  /*
    // file is healthy
    while (fgets(line, sizeof(line), file) != NULL) {
        num_items++;
    }
    fclose(file);*/
  
    file = fopen(fname, "r");
    int i =0;

    // allocate memory to menu's parts. i.e., codes, names, and costs
  // ALLOCATE MEM
    char** item_codes = (char**) malloc(sizeof(char*)*num_items);
    char** item_names = (char**) malloc(sizeof(char*)*num_items);
    double* item_costs = (double*) malloc(sizeof(double)*num_items);

    // read the file
    while (fgets(line, sizeof(line), file) != NULL) {

        int j = 0;

        // trim leading and trailing white spaces and also \n at the end
        char *line_trimmed = trim_whitespace(line);
        char* to_be_deleted = line_trimmed;

        // split the line wit regards to MENU_DELIM
        char* token = strtok(line_trimmed, MENU_DELIM);
        while (token != NULL) {
            if (j == 0) {
                // we are dealing with item code
                char* item_code = (char*) malloc(sizeof(char)*ITEM_CODE_LENGTH);
                memset(item_code, '\0', sizeof(char) * ITEM_CODE_LENGTH);
                strcpy(item_code, token);
                item_codes[i] = item_code;
            }
            else if (j == 1) {
                // we are dealing with item name
                char* item_name = (char*) malloc(sizeof(char)*MAX_ITEM_NAME_LENGTH);
                memset(item_name, '\0', sizeof(char) * MAX_ITEM_NAME_LENGTH);
                strcpy(item_name, token);
                item_names[i] = item_name;
            } else {
                // we are dealing with item cost
                char* p;
                double item_cost = strtod(token+1, &p);
                item_costs[i] = item_cost;
            }
            j++;
            token = strtok(NULL, MENU_DELIM);
        }
        i++;

        // line_trimmed have been allocated dynamically in our helper function
        // it's our responsibility to clear the allocated memory
        free(to_be_deleted);
    }
    fclose(file);

    // attach attributes to the menu
    menu->num_items = num_items;
    menu->item_codes = item_codes;
    menu->item_names = item_names;
    menu->item_cost_per_unit = item_costs;
    return menu;
}
